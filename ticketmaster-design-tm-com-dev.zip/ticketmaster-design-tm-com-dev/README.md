# Ticketmaster Design Front-end Application

* Node Version: 18.17.1

## Getting started

After cloning this repo, run the following commands to get started.

```shell
npm install
```

Then, you can run locally in development mode with live reload:

```shell
npm run dev
```

## Boilerplate Info

This project was initally cloned from the NextJS Boilerplate project. The purpose of this is to save time configuring many of the developer tooling needed in a NextJS project. However, a few changes have been made to better fit developpment at Huge Inc. The original README can be found [here](./docs/README-ORIG.md).

* Structure: `src/layout` will be the place used to hold global application components.  `Main` and `Meta` have been moved into this directory. Templates will be used for page templates.
* Linting: The "tailwindcss/no-custom-classname" rule has been disabled.
