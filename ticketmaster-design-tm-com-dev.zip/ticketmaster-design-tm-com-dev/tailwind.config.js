/** @type {import('tailwindcss').Config} */

// eslint-disable-next-line import/no-extraneous-dependencies
// import {
//   white as _white,
//   black as _black,
//   transparent as _transparent,
// } from 'tailwindcss/colors';

export const content = ['./src/**/*.{js,ts,jsx,tsx}'];
export const theme = {
  fontSize: {
    xs: '0.75rem',
    sm: '0.875rem',
    base: '1rem',
    lg: '1.125rem',
    xl: '1.25rem',
    '2xl': '1.5rem',
    '3xl': '1.875rem',
    '4xl': '2.25rem',
    '5xl': '3rem',
    '6xl': '4rem',
  },
  fontFamily: {
    black: 'Averta Black, sans-serif',
    blackItalic: 'Averta Black Italic, sanis-serif',
    bold: 'Averta Bold, sanis-serif',
    boldItalic: 'Averta Bold Italic, sanis-serif',
    extraBold: 'Averta Extra Bold, sanis-serif',
    extraBoldItalic: 'Averta Extra bold Italic, sanis-serif',
    extraThin: 'Averta Extra Thin, sanis-serif',
    extraThinItalic: 'Averta Extra Thin Italic, sanis-serif',
    light: 'Averta Light, sanis-serif',
    lightItalic: 'Averta Light Italic, sanis-serif',
    regular: 'Averta Regular, sanis-serif',
    regularItalic: 'Averta Regular Italic, sanis-serif',
    semiBold: 'Averta Semi Bold, sans-serif',
    semiBoldItalic: 'Averta Semi Bold Italic, sans-serif',
    thin: 'Averta Thin, sanis-serif',
    thinItalic: 'Averta Thin Italic, sanis-serif',
  },
  // colors: {
  //   white: _white,
  //   black: _black,
  //   transparent: _transparent,
  //   darkBlue: '#024DDF',
  //   blue: '#024DDF',
  //   purple: '#9747FF',
  //   violet: '#8A44E8',
  //   yellow: '#FBFF2C',
  // },
  extend: {
    gridTemplateColumns: {},
    gridTemplateRows: {},
    colors: {
      background: 'var(--color-background)',
      typography: 'var(--color-typography',
      headline: 'var(--color-headline)',
      headlineInactive: 'var(--color-headlineInactive)',
      link: 'var(--color-link)',
      eyebrow: 'var(--color-eyebrow)',
      blue: 'var(--color-blue)',
      line: 'var(--color-line)',
    },
  },
};
