import GlobalNav from './GlobalNav';

export default GlobalNav;
