/* eslint-disable jsx-a11y/no-static-element-interactions */

'use client';

import gsap from 'gsap';
import Image from 'next/image';
import Link from 'next/link';
import type { MouseEvent, ReactNode } from 'react';
import { useContext, useEffect, useRef, useState } from 'react';

import type { INav, INavItem } from '@/components/Nav';
import NavigationContext from '@/context/NavigationContext';
import useLayoutEffect from '@/hooks/useIsomorphicLayoutEffect';

import styles from './globalNav.module.css';

interface GlobalNavTileProps {
  image?: string;
  altText?: string;
  title?: string;
  onClick: (e: MouseEvent) => void;
}

const GlobalNavTile = ({
  image,
  altText,
  title,
  onClick,
}: GlobalNavTileProps) => {
  return (
    <div
      className={`${styles.nav_tile} hover:!opacity-100`}
      aria-hidden="true"
      onClick={onClick}
      role="navigation"
      aria-label={altText}
    >
      {image && altText ? (
        <Image
          src={image}
          alt={altText}
          objectFit="cover"
          fill
          className="absolute left-0 top-0 aspect-video h-auto w-full"
          unoptimized
        />
      ) : null}
      {title && <span className={styles.tileTitle}>{title}</span>}
    </div>
  );
};

const GlobalNav = ({ items }: INav) => {
  const { isNavOpen, setIsNavOpen } = useContext(NavigationContext);

  const [navItems, setNavItems] = useState<INavItem[]>();
  const [subNavItems, setSubNavItems] = useState<INavItem>();
  const [interiorNavItems, setInteriorNavItems] = useState<
    { label: string; link?: string | undefined }[] | undefined
  >();
  const [interiorLabel, setInteriorLabel] = useState('');

  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setNavItems(items);
  }, [items]);

  useEffect(() => {
    if (!isNavOpen) {
      setSubNavItems(undefined);
      setInteriorNavItems(undefined);
      setInteriorLabel('');
    }
  }, [isNavOpen]);

  const closeMenu = () => {
    setSubNavItems(undefined);
    setInteriorNavItems(undefined);
    setInteriorLabel('');
    setIsNavOpen(false);
  };

  const openSubNav = (): ReactNode => {
    return subNavItems ? (
      <div className={styles.subnav}>
        <div className={styles.subnav_heading}>{subNavItems.label}</div>
        <ul>
          {subNavItems?.children?.map((child: any) => (
            <li key={child.label} className={styles.subnav_item}>
              {child.link ? (
                <Link href={child.link}>
                  <button
                    type="button"
                    className="uppercase"
                    onClick={() => closeMenu()}
                  >
                    {child.label}
                  </button>
                </Link>
              ) : (
                <div
                  className="cursor-default"
                  role="button"
                  tabIndex={0}
                  onClick={(e: MouseEvent) => {
                    e.preventDefault();
                    setInteriorNavItems(child?.children);
                    setInteriorLabel(child.label);
                  }}
                  onKeyDown={() => {
                    setInteriorNavItems(child?.children);
                    setInteriorLabel(child.label);
                  }}
                >
                  {child.label}
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    ) : null;
  };

  const openInteriorNav = (): ReactNode => {
    return interiorNavItems ? (
      <div className={styles.subnav}>
        <div className={styles.subnav_heading}>{interiorLabel}</div>
        <ul>
          {interiorNavItems?.map((child: any) => (
            <li key={child.label} className={styles.subnav_item}>
              {child.link ? (
                <Link href={child.link}>
                  <button
                    type="button"
                    className="uppercase"
                    onClick={() => closeMenu()}
                  >
                    {child.label}
                  </button>
                </Link>
              ) : null}
            </li>
          ))}
        </ul>
      </div>
    ) : null;
  };

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      if (isNavOpen) {
        gsap.fromTo(
          '[class*="nav_tile"]',
          { opacity: 0, x: -500 },
          {
            opacity: 0.7,
            x: 0,
            duration: 0.2,
            stagger: 0.03,
            ease: 'power1.out',
          },
        );
      }
    }, navRef);

    return () => ctx.revert();
  }, [isNavOpen]);

  return isNavOpen && items ? (
    <div className={styles.nav_global_container}>
      <div ref={navRef} className={styles.nav_global_menu}>
        {navItems?.map((navItem: any) => {
          return (
            <GlobalNavTile
              key={navItem.label}
              image={navItem?.image?.src}
              altText={navItem?.image?.alt}
              title={navItem?.label}
              onClick={(e: MouseEvent) => {
                e.preventDefault();
                setSubNavItems(navItem);
              }}
            />
          );
        })}
      </div>
      <div
        className={styles.nav_backdrop}
        onClick={(e: MouseEvent) => {
          e.preventDefault();
          closeMenu();
        }}
        onKeyDown={() => {
          closeMenu();
        }}
      />
      {subNavItems && (
        <div className={styles.nav_global_subMenu}>{openSubNav()}</div>
      )}
      {interiorNavItems && (
        <div className={styles.nav_global_interiorMenu}>
          {openInteriorNav()}
        </div>
      )}
    </div>
  ) : null;
};

export default GlobalNav;
