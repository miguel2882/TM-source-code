import Link from 'next/link';
import React from 'react';

import NavLogo from '@/components/NavLogo';

const footerCol =
  'col-span-8 flex items-center justify-center py-12 lg:col-span-2';

export default function Footer() {
  return (
    <footer className="tm-grid theme-black relative z-20 py-8 text-sm">
      <div className={footerCol}>
        <NavLogo href="/core" onClick={() => null} />
      </div>
      <div className={footerCol}>
        <p className="max-w-[460px] px-12 text-center text-3xl lg:text-left">
          To design the future of live entertainment.
        </p>
      </div>
      <div className="items-left col-span-8 flex flex-col justify-center py-12 pl-12 font-bold text-xl sm:col-span-4 lg:col-span-2">
        <h4 className="text-xl uppercase text-blue">Title</h4>
        <ul className="">
          <li className="py-2">
            <Link href="/core">Core</Link>
          </li>
          <li className="py-2">
            <Link href="/marketing">Marketing</Link>
          </li>
          <li className="py-2">
            <Link href="/product">Product</Link>
          </li>
          <li className="py-2">
            <Link href="/careers">Careers</Link>
          </li>
        </ul>
      </div>
      <div className="items-left col-span-8 flex flex-col justify-center py-12 pl-12 font-bold text-xl sm:col-span-4 lg:col-span-2">
        <h4 className="text-xl uppercase text-blue">Title</h4>
        <ul>
          <li className="py-2">
            <Link href="/core/guidelines">brand guidelines</Link>
          </li>
          <li className="py-2">example link text with more words</li>
          <li className="py-2">example link</li>
          <li className="py-2">example link four words</li>
        </ul>
      </div>
    </footer>
  );
}
