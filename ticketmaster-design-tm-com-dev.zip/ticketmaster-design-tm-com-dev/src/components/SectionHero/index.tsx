import type { ISectionHero } from './SectionHero';
import SectionHero from './SectionHero';

export type { ISectionHero };

export default SectionHero;
