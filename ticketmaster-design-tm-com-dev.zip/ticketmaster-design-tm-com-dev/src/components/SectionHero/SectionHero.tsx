/* eslint-disable react/no-unused-prop-types */
import styles from './hero.module.css';

export interface ISectionHero {
  title: string;
  id?: string;
  theme?: string;
  index?: number;
  image?: {
    src: string;
    alt: string;
    caption?: string;
    title?: string;
  };
}

const SectionHero = (props: ISectionHero) => {
  const { title, index, image } = props;
  return (
    <section className="tm-hero tm-4x4 tm-grid-fill w-full overflow-hidden">
      <div className="cell relative col-span-8 row-span-4 flex h-full items-center border-none">
        <div className="absolute h-full w-full bg-black" />
        {image?.src && (
          <img
            className="absolute h-full w-full object-cover opacity-[0.7]"
            src={image.src}
            alt=""
          />
        )}

        <div className="absolute top-[50%] flex h-[50%] w-full flex-col items-center justify-between">
          <h1 className="translate-y-[-50%] text-[56px] font-normal leading-[47.5px] md:text-[118px]">
            {title}
          </h1>
          <h2 className="font-light text-[110px]">{index}</h2>
          <img
            className={`${styles.hero__arrow} z-10 pb-[84px]`}
            src="/assets/images/core/arrow-down.svg"
            alt=""
          />
        </div>
      </div>
    </section>
  );
};

export default SectionHero;
