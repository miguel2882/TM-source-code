import type { IImage } from '@/components/Image';
import Image from '@/components/Image';
import SectionWrap from '@/components/SectionWrap';

const paraClasses =
  'cell p-10 col-span-8 md:col-span-4 lg:col-span-3 2xl:col-span-2 items-start flex h-full';

export interface ISectionIntro {
  title: string;
  id: string;
  theme: string;
  eyebrow: string;
  headline: string;
  image?: IImage;
  support: {
    eyebrow: string;
    copy: string;
  }[];
}

const SectionIntro = (props: ISectionIntro) => {
  const { title, eyebrow, headline, support, image } = props;
  return (
    <SectionWrap {...props}>
      <div className="tm-grid">
        <div className="cell col-span-8 flex h-full items-center px-4 lg:col-span-2  lg:row-span-4">
          <h2 className="heading-2xl">{title}</h2>
        </div>

        <div className="cell aspect-16-9 relative col-span-8 row-span-2 flex h-full items-end p-8 lg:col-span-6 lg:row-span-3">
          {image && (
            <Image
              {...image}
              alt={image.alt || ''}
              captionPosition="bottom"
              className="aspect-16-9 absolute left-0 top-0 z-0 h-full w-full"
            />
          )}
          <h3 className="heading-xl z-10 max-w-[490px]">
            <span className="eyebrow w-full">{eyebrow}</span>
            {headline}
          </h3>
        </div>
        <div className="cell col-span-2 row-span-3 hidden  h-full items-center 2xl:flex" />

        {support.map((block) => (
          <div key={block.copy} className={paraClasses}>
            <p className="body-copy">
              {eyebrow && <span className="eyebrow">{block.eyebrow}</span>}
              {block.copy}
            </p>
          </div>
        ))}
      </div>
    </SectionWrap>
  );
};

export default SectionIntro;
