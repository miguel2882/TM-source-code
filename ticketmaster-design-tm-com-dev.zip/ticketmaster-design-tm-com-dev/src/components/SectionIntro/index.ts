import type { ISectionIntro } from './SectionIntro';
import SectionIntro from './SectionIntro';

export type { ISectionIntro };

export default SectionIntro;
