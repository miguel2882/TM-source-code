import type { INav, INavItem } from './Nav';
import Nav from './Nav';

export default Nav;
export type { INav, INavItem };
