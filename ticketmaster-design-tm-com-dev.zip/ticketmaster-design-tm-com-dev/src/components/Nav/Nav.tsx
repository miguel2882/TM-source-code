import React, { useMemo, useState } from 'react';

import FloatingNavButton from '@/components/FloatingNavButton';
import GlobalNav from '@/components/GlobalNav';
import NavLogo from '@/components/NavLogo';
import NavigationContext from '@/context/NavigationContext';

import styles from './nav.module.css';

export interface INav {
  items: INavItem[];
}

export interface INavItem {
  label: string;
  link: string;
  image?: {
    src: string;
    alt: string;
  };
  children?: {
    label: string;
    link?: string;
    children?: {
      label: string;
      link?: string;
    }[];
  }[];
}

const Nav = ({ items }: INav) => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const value = useMemo(
    () => ({ isNavOpen, setIsNavOpen }),
    [isNavOpen, setIsNavOpen],
  );
  return (
    <NavigationContext.Provider value={value}>
      <nav className={styles.nav}>
        <FloatingNavButton labelText="Menu" />
        <NavLogo href="/core" onClick={() => null} />
        <GlobalNav items={items} />
      </nav>
    </NavigationContext.Provider>
  );
};

export default Nav;
