import React from 'react';

import type { IImage } from '../Image';
import Image from '../Image';
import type { ISection } from '../SectionWrap/SectionWrap';
import SectionWrap from '../SectionWrap/SectionWrap';

export interface ILinkItem {
  title: string;
  subtitle: string;
  url: string;
  icon?: string;
  target?: string;
}

export interface ISectionLinks extends ISection {
  type: 'links';
  innerTheme?: string;
  image?: IImage;
  links?: ILinkItem[];
  headline?: string;
  eyebrow?: string;
  titleTheme?: string;
}

function Linkitem(props: ILinkItem) {
  const { title, subtitle, url, icon, target } = props;
  return (
    <li className="tm-links__list-item  flex w-full flex-wrap items-center justify-between border-l border-t border-line bg-black p-[24px] uppercase md:px-[50px] md:py-[30px]">
      <p className="!my-0 flex-[0_1_75%] md:flex-[1_1_66%]">{title}</p>
      <p className="flex=[1_0_100%] order-first !my-0 md:order-none md:flex-[1_1_16.5%]">
        {subtitle}
      </p>
      <a className="item-end" target={target} href={url}>
        <span>Download</span>
        {icon && <i />}
      </a>
    </li>
  );
}

export default function SectionLinks(props: ISectionLinks) {
  const { title, image, links, eyebrow, headline, innerTheme } = props;

  return (
    <SectionWrap {...props}>
      <div className="tm-grid relative z-20">
        <div className="cell col-span-8 row-span-3 !row-start-1 flex h-full w-screen items-center justify-center border-none md:col-span-2 md:row-span-4 md:w-full">
          <h2 className="heading-2xl">{title}</h2>
        </div>
        <div
          data-theme={innerTheme}
          className="cell col-span-8 row-span-3 !row-start-1 flex h-full items-center justify-center  bg-cover bg-center bg-no-repeat md:col-span-6 md:col-start-3 md:row-span-3"
        >
          {image ? (
            <Image
              {...image}
              className="h-full w-full border-l border-line object-cover "
              alt=""
            />
          ) : null}
        </div>
        <div
          data-theme={innerTheme}
          className="cell  md:ps-p0 col-span-8 !row-span-1 flex h-full w-screen items-center border-none ps-[40px] md:col-span-4 md:col-start-3 md:!row-start-3 md:w-full md:justify-center"
        >
          <div className="py-[32px] md:pb-[78px] md:pe-[100px]">
            <h3 className="heading-xl">
              <span className="eyebrow">{eyebrow}</span>
              {headline}
            </h3>
          </div>
        </div>
        <div className="cell col-span-8 !row-start-5 flex h-full w-screen border-none  md:col-span-6 md:!col-start-3 md:w-full">
          <ul className="tm-links__list line-botttom !my-0 w-full">
            {links &&
              links.map((link) => <Linkitem key={link.url} {...link} />)}
          </ul>
        </div>
      </div>
    </SectionWrap>
  );
}
