import type { ISectionLinks } from './SectionLinks';
import SectionLinks from './SectionLinks';

export type { ISectionLinks };

export default SectionLinks;
