'use client';

import Image from 'next/image';
import Link from 'next/link';

import styles from './navlogo.module.css';

interface INavLogoProps {
  href: string;
  onClick: () => void;
}

const NavLogo = ({ href, onClick }: INavLogoProps) => {
  return (
    <div className={styles.navLogo}>
      <Link href={href} onClick={onClick}>
        <Image
          priority
          src="/assets/images/tm_logo.svg"
          alt="Ticketmaster Logo"
          width={126}
          height={38}
        />
      </Link>
    </div>
  );
};

export default NavLogo;
