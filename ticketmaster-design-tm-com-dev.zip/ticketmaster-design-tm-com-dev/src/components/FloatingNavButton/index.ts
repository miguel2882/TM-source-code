import FloatingNavButton from './FloatingNavButton';

export default FloatingNavButton;
