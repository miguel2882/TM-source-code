'use client';

import React, { useContext } from 'react';

import NavigationContext from '@/context/NavigationContext';

import styles from './floatingNavButton.module.css';

interface IFloatingNavButton {
  labelText: string;
}

const FloatingNavButton = ({ labelText }: IFloatingNavButton) => {
  const { isNavOpen, setIsNavOpen } = useContext(NavigationContext);

  return (
    <button
      type="button"
      onClick={() => setIsNavOpen(!isNavOpen)}
      className={styles.floating_nav_button}
    >
      {isNavOpen ? 'Exit' : labelText}
    </button>
  );
};

export default FloatingNavButton;
