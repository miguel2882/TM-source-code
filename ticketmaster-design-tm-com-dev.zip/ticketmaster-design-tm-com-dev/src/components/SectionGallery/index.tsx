import type { ISectionGallery } from './SectionGallery';
import SectionGallery from './SectionGallery';

export type { ISectionGallery };

export default SectionGallery;
