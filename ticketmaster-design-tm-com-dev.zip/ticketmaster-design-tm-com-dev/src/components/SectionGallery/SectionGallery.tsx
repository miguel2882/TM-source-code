/* eslint-disable jsx-a11y/anchor-is-valid */
import SectionWrap from '../SectionWrap/SectionWrap';
import styles from './gallery.module.css';

export interface ISectionGallery {
  title: string;
  id: string;
  theme: string;
  index: number;
  image: {
    src: string;
    alt: string;
    caption?: string;
  };
}

const SectionGallery = (props: ISectionGallery) => {
  // const { title, index, image } = props;
  return (
    <SectionWrap {...props} className="tm-gallery">
      <div className="tm-4x4 min-h-screen">
        <div className="cell col-span-8 row-span-4 h-full border-none md:col-span-2">
          <div className="flex h-full w-full items-center justify-center">
            <h2 className="heading-2xl">Foundations</h2>
          </div>
        </div>

        <div className="cell col-span-8 row-span-4 h-screen border-none md:col-span-2 md:h-full">
          <div className="flex w-full ps-[30px] md:h-[25%] md:items-end md:ps-0">
            <div className="md:mb-[80px]">
              <h5 className="font-supply my-0 text-[12px] uppercase text-[#A7A7A7] md:hidden">
                Foundation 1
              </h5>
              <h3 className="text-[48px] leading-[48px] md:text-[24px]">
                Motion
              </h3>
            </div>
          </div>
          <div
            className={`${styles.tm_gallery__image} aspect-16-9 flex w-full items-center py-[50px] md:py-0`}
          >
            <img
              className="h-full w-full object-contain object-left"
              src="/assets/images/core/foundations-motion.png"
              alt=""
            />
          </div>
          <div className="w-full px-[30px] md:hidden md:h-[25%]">
            <h2 className="pb-[42px] text-[34px] leading-[37px]">
              We’ve built our motion system to mimic the fluidity of sound
            </h2>
            <h4 className="pb-[20px] text-[24px]">Sequencing</h4>
            <p className="!my-0">
              Through motion, we seek to create a seamless and immersive journey
              that mirrors the harmony and rhythm of sound.
            </p>
          </div>
        </div>

        <div className="cell col-span-8 row-span-4 h-screen border-none md:col-span-2 md:h-full">
          <div className="flex w-full ps-[30px] md:h-[25%] md:items-end md:ps-0">
            <div className="md:mb-[80px]">
              <h5 className="font-supply my-0 text-[12px] uppercase text-[#A7A7A7] md:hidden">
                Foundation 2
              </h5>
              <h3 className="text-[48px] leading-[48px] md:text-[24px]">
                Iconography
              </h3>
            </div>
          </div>
          <div
            className={`${styles.tm_gallery__image} aspect-16-9 flex w-full items-center py-[50px] md:py-0`}
          >
            <img
              className="h-full w-full object-contain object-left"
              src="/assets/images/core/foundations-icons.png"
              alt=""
            />
          </div>
          <div className="w-full px-[30px] md:hidden md:h-[25%]">
            <h2 className="pb-[42px] text-[34px] leading-[37px]">
              We’ve built our motion system to mimic the fluidity of sound
            </h2>
            <h4 className="pb-[20px] text-[24px]">Sequencing</h4>
            <p className="!my-0">
              Through motion, we seek to create a seamless and immersive journey
              that mirrors the harmony and rhythm of sound.
            </p>
          </div>
        </div>

        <div className="cell col-span-8 row-span-4 h-screen border-none md:col-span-2 md:h-full">
          <div className="flex w-full ps-[30px] md:h-[25%] md:items-end md:ps-0">
            <div className="md:mb-[80px]">
              <h5 className="font-supply my-0 text-[12px] uppercase text-[#A7A7A7] md:hidden">
                Foundation 3
              </h5>
              <h3 className="text-[48px] leading-[48px] md:text-[24px]">
                Typography
              </h3>
            </div>
          </div>
          <div
            className={`${styles.tm_gallery__image} aspect-16-9 flex w-full items-center py-[50px] md:py-0`}
          >
            <img
              className="h-full w-full object-contain object-left"
              src="/assets/images/core/foundations-type.png"
              alt=""
            />
          </div>
          <div className="w-full px-[30px] md:hidden md:h-[25%]">
            <h2 className="pb-[42px] text-[34px] leading-[37px]">
              We’ve built our motion system to mimic the fluidity of sound
            </h2>
            <h4 className="pb-[20px] text-[24px]">Sequencing</h4>
            <p className="!my-0">
              Through motion, we seek to create a seamless and immersive journey
              that mirrors the harmony and rhythm of sound.
            </p>
          </div>
        </div>

        <div className="col-span-2 col-start-7 row-span-1 hidden md:block">
          <a
            className="flex h-full w-full items-center justify-center hover:border-none"
            href="#"
          >
            <span className="pe-[22px] text-[18px] font-semibold uppercase text-white	">
              Next
            </span>
            <img
              className=""
              src="/assets/images/core/arrow-right.svg"
              alt=""
            />
          </a>
        </div>
      </div>
    </SectionWrap>
  );
};

export default SectionGallery;
