import ScrollTrigger from 'gsap/dist/ScrollTrigger';
import React, { useEffect, useRef, useState } from 'react';

export interface ISection {
  title: string;
  id: string;
  theme: string;
  children?: React.ReactNode;
  className?: string;
}

const SectionWrap = ({ title, children, id, theme, className }: ISection) => {
  const thisRef = useRef(null);
  // Set up a state called isVisible, and set it to false.
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = thisRef.current;

    // Provisional ScrollTrigger
    // Need to variable-ize the start value, create a func to do things
    // like swap out the page theme, change the pinned title, etc.
    //
    // MJ NOTE: I feel like 50% might be the right value, since that's
    // where the headline will be pinned (roughly).
    const visibleTrigger = ScrollTrigger.create({
      trigger: el,
      start: 'top 50%',
      end: 'bottom 50%',
      toggleClass: 'section--visible',
      onEnter: () => {
        setIsVisible(true);
        console.log('enter', title, isVisible);
      },
      onLeave: () => {
        setIsVisible(false);
        console.log('leave', title, isVisible);
      },
      onEnterBack: () => {
        setIsVisible(true);
        console.log('enter back', title, isVisible);
      },
      onLeaveBack: () => {
        setIsVisible(false);
        console.log('leave back', title, isVisible);
      },
    });

    return () => {
      // Cleanup.
      // When we unmount, we want to kill the ScrollTriggers.
      visibleTrigger.kill();
    };
  }, []);

  return (
    <section
      id={id}
      className={`section theme-${theme} ${className || ''} min-h-screen`}
      ref={thisRef}
      data-theme={theme}
    >
      <h2 className="section-title">{title}</h2>
      {children}
    </section>
  );
};

export default SectionWrap;
