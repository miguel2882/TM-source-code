import type { ISection } from './SectionWrap';
import Section from './SectionWrap';

export type { ISection };

export default Section;
