/* eslint-disable jsx-a11y/anchor-is-valid */
import SectionWrap from '../SectionWrap/SectionWrap';

export interface ISectionSidetrack {
  title: string;
  id: string;
  theme: string;
  index: number;
  image: {
    src: string;
    alt: string;
    caption?: string;
  };
}

const SectionSidetrack = (props: ISectionSidetrack) => {
  const { title } = props;
  return (
    <SectionWrap {...props}>
      <div className="tm-sidetrack__primary tm-4x3 relative">
        <div className="cell relative col-span-8 row-span-1 md:col-span-4 md:row-span-2">
          <img
            className="h-full w-full object-cover opacity-[0.6] md:opacity-[1]"
            src="/assets/images/core/core-principals.png"
            alt=""
          />
        </div>
        <div className="cell col-span-8 row-span-2 flex items-center md:col-span-2">
          <div className="pe- p-[60px] md:ps-[40px]">
            <h4 className="block text-[36px] leading-[37.5px]">
              <span className="eyebrow my-0">HOW WE MAKE IT POSSIBLE</span>
              We are designing the future of live entertainment.
            </h4>
          </div>
        </div>

        <div className="cell absolute col-span-8 !col-start-1 row-span-1 !row-start-1 flex h-full w-full items-center justify-center md:col-span-2 md:row-span-2">
          <h2 className="heading-2xl absolute">{title}</h2>
        </div>

        <div className="cell col-span-2 col-start-7 row-span-1 row-start-3 hidden md:block">
          <a
            className="flex h-full w-full items-center justify-center hover:border-none"
            href="#"
          >
            <span className="pe-[22px] text-[18px] font-semibold uppercase text-white	">
              Explore
            </span>
            <img src="/assets/images/core/arrow-right.svg" alt="" />
          </a>
        </div>
      </div>
      <div className="tm-sidetrack__secondary">
        <div className="tm-4x4 tm-grid">
          <div className="cell relative col-span-8 row-start-2 flex h-full items-center border-none bg-cover bg-center bg-no-repeat md:col-span-4 md:row-span-2 md:row-start-2">
            <img
              className="h-full w-full object-cover"
              src="/assets/images/core/principal-polished.png"
              alt=""
            />
          </div>
          <div className="cell relative col-span-7 col-start-1 flex items-center border-none md:col-span-2 md:row-span-2 md:row-start-2 md:h-full md:justify-center">
            <div className="pb-[18px] ps-[30px] md:pb-[0px] md:ps-[0px]">
              <h5 className="font-supply my-0 text-[12px] text-[#A7A7A7]">
                PRINCIPLE 1
              </h5>
              <h3 className="text-[48px] leading-[47.5px]">Polished</h3>
            </div>
          </div>
          <div className="cell relative col-span-2 row-span-2 row-start-2 flex h-full items-center border-none md:flex">
            <p className="pe-[135px] ps-[20px]">
              It’s Ticketmaster’s mission to make that connection between fans
              and the artists, teams and performers they love. The power of our
              brand lies in that connection point.
            </p>
          </div>
          <div className="col-span-8 p-[40px] text-center md:hidden">
            TODO: Make carousel controls
          </div>
        </div>
        <div className="tm-4x3 tm-grid !hidden md:!grid">
          <div className="cell relative col-span-4 row-span-2 flex h-full items-center border-none bg-cover bg-center bg-no-repeat">
            <img src="/assets/images/core/principal-dynamic.png" alt="" />
          </div>
          <div className="cell relative col-span-2 row-span-2 flex h-full items-center justify-center border-none">
            <div>
              <h5 className="font-supply my-0 text-[12px] text-[#A7A7A7]">
                PRINCIPLE 2
              </h5>
              <h3 className="text-[48px] leading-[47.5px]">Dynamic</h3>
            </div>
          </div>
          <div className="cell relative col-span-2 row-span-2 flex h-full items-center border-none">
            <p className="hidden pe-[135px]  ps-[20px] md:flex">
              Brand elements pulsate, expand, and contract in sync with the
              audio, creating an interplay between sound and motion.
            </p>
          </div>
          <div className="cell col-span-2 row-span-1 row-start-3 flex h-full items-center border-none">
            <a
              className="flex h-full w-full items-center justify-center hover:border-none"
              href="#"
            >
              <img
                className=""
                src="/assets/images/core/arrow-left.svg"
                alt=""
              />
              <span className="ps-[22px] text-[18px] font-semibold uppercase text-white	">
                Back
              </span>
            </a>
          </div>
        </div>
      </div>
    </SectionWrap>
  );
};

export default SectionSidetrack;
