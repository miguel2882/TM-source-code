import type { ISectionSidetrack } from './SectionSidetrack';
import SectionSidetrack from './SectionSidetrack';

export type { ISectionSidetrack };

export default SectionSidetrack;
