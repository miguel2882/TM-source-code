import Image from 'next/image';
import React from 'react';

export interface IImage {
  src: string;
  alt: string;
  caption?: string;
  captionPosition?: 'below' | 'bottom';
  height?: number;
  width?: number;
  className?: string;
}

const captionClasses = {
  below: 'absolute right-4 -bottom-8 caption',
  bottom: 'absolute right-4 bottom-4 caption',
};

export default function TMImage(props: IImage) {
  const {
    src,
    alt,
    caption,
    captionPosition = 'below',
    height,
    width,
    className,
  } = props;

  const sizeProps = height && width ? { height, width } : { fill: true };

  return (
    <div className={` ${className || 'relative'}`}>
      <Image src={src} alt={alt} {...sizeProps} className="object-cover" />
      {caption && (
        <div className={captionClasses[captionPosition]}>{caption}</div>
      )}
    </div>
  );
}
