import type { IImage } from './Image';
import Image from './Image';

export type { IImage };

export default Image;
