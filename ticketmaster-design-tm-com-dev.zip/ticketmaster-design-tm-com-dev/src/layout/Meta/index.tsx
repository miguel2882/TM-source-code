import type { IMetaProps } from './Meta';
import { Meta } from './Meta';

export type { IMetaProps };

export default Meta;
