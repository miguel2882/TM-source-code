import type { ReactNode } from 'react';
import React from 'react';

import Footer from '@/components/Footer';
import type { INav } from '@/components/Nav';
import Nav from '@/components/Nav';
import BreakpointUtility from '@/components/Utils/Breakpoints';

type IMainProps = {
  children: ReactNode;
  nav: INav;
};

const Main = (props: IMainProps) => {
  const { children, nav } = props;

  return (
    <main className="theme-black w-full antialiased">
      <BreakpointUtility />
      <Nav {...nav} />
      <div className="mx-auto">
        <main className="content min-h-screen">
          <div className="tm-grid-lines" />
          {children}
        </main>
      </div>
      <Footer />
    </main>
  );
};

export { Main };
