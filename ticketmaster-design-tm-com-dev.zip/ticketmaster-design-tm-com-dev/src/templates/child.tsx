import React from 'react';

import TMImage from '@/components/Image/Image';

interface IChildTemplateProps {
  page: {
    slug: string;
    parent: string;
    // TODO: This should reference the hero interface when that exists
    hero: {
      title: string;
    };
  };
}

const ChildTemplate = (props: IChildTemplateProps) => {
  const { page } = props;
  return (
    <div className="tm-grid theme-white min-h-screen">
      <div className="col-span-8 lg:col-span-2">
        <h1 className="line-bottom px-8 py-12 text-[48px] leading-[48px] lg:py-36 ">
          {page?.hero?.title}
        </h1>
        <div className="line-bottom px-8 py-4 uppercase">Subtitle</div>
        <div className="line-bottom px-8 py-4 uppercase text-blue">
          Active Section Name
        </div>
      </div>

      <div className="col-span-8 px-8 lg:col-span-4 lg:px-12 ">
        <h2 className="pt-8 text-[74px] text-blue lg:pt-40 lg:text-[96px]">
          Grid
        </h2>
        <p className="pb-12 text-[30px] leading-[30px]">
          Grid systems are used for creating page layouts through a series of
          rows and columns that house your content. Ticketmaster uses a
          responsive, mobile first, fluid grid system that appropriately scales
          up to 12 columns as the device or viewport size increases.
        </p>
        <h3 className="bold">1440 - 768px</h3>
        <p>
          This breakpoint range covers all desktop and tablet use cases with
          margins and gutters set at 24px.
        </p>
        <TMImage
          src="/assets/images/grid.png"
          alt="Grid"
          height={632}
          width={950}
          className=" -mx-8 my-12 lg:-mx-12"
        />
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </div>
    </div>
  );
};

export default ChildTemplate;
