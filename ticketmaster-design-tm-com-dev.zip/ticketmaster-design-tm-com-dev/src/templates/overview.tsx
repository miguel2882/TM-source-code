// @ts-nocheck

import SectionGallery from '@/components/SectionGallery';
import SectionHero from '@/components/SectionHero';
import type { ISectionIntro } from '@/components/SectionIntro';
import SectionIntro from '@/components/SectionIntro';
import SectionLinks from '@/components/SectionLinks';
import SectionSidetrack from '@/components/SectionSidetrack';
import type { ISection } from '@/components/SectionWrap/SectionWrap';
import SectionWrap from '@/components/SectionWrap/SectionWrap';

export interface ISectionExtended extends ISection {
  type: 'links' | 'sidetrack' | 'gallery';
}

export interface IPage {
  slug: string;
  hero: {
    title: string;
  };
  sections: ISectionExtended[];
  intro: ISectionIntro;
}

function Unknown(props: ISection) {
  return (
    <SectionWrap {...props}>
      Unknown Component: {props.id}
      <h2 className="text-xl">{props.title}</h2>
    </SectionWrap>
  );
}

const sectionComponents = {
  links: SectionLinks,
  sidetrack: SectionSidetrack,
  gallery: SectionGallery,
};

const OverviewTemplate = (props: { page: IPage }) => {
  const { page } = props;
  const { sections, hero, intro } = page;
  return (
    <div>
      <SectionHero {...hero} />
      <SectionIntro {...intro} />
      {sections.map((section) => {
        if (!section.type) return Unknown(section);
        const SectionComponent = sectionComponents[section.type] || Unknown;
        return SectionComponent ? (
          <SectionComponent key={section.id} {...section} />
        ) : null;
      })}
    </div>
  );
};

export default OverviewTemplate;
