import React from 'react';

const HomeTemplate = () => {
  return (
    <div>
      <h1>Home Template</h1>
    </div>
  );
};

export default HomeTemplate;
