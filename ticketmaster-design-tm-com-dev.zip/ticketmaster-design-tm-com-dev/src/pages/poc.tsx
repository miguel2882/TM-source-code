const para =
  'Fans seeking unforgettable moments to the artists, teams, and event creators who are powering incredible live events, to Ticketmaster employees and the industry at large. And within that diversity, the commonality is the passion, joy and excitement of being at a live event — or being a part of putting on a live event.';

const paraClasses =
  'cell pl-8 col-span-8 md:col-span-4 lg:col-span-3 2xl:col-span-2 items-center flex h-full';

const Poc = () => (
  <section className="section-vip">
    <div className="cell col-span-8 flex h-full items-center lg:col-span-2 lg:row-span-4">
      <h1 className="text-[56px] leading-none lg:text-[64px]">What we Do</h1>
    </div>
    <div className="cell col-span-8 row-span-2 flex h-full items-end bg-blue p-8 lg:col-span-6 lg:row-span-3">
      <h1 className="max-w-[480px] text-2xl">
        This version attempts to put everythign in a single viewport. Each row
        is 1/4 of the hight of the viewport. In this, our viewport and its
        porportions is the source of truth.
      </h1>
    </div>
    <div className="cell col-span-2 row-span-3 hidden  h-full items-center bg-blue 2xl:flex" />

    <div className={paraClasses}>
      <p className="body-copy">{para}</p>
    </div>
    <div className={paraClasses}>
      <p className="body-copy">{para}</p>
    </div>
  </section>
);

export default Poc;
