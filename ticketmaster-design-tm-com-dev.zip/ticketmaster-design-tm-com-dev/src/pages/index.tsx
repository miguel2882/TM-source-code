import homeData from '@/data/home';
import navData from '@/data/nav';
import HomeTemplate from '@/templates/home';

export default HomeTemplate;

export const getStaticProps = async () => {
  const props = {
    page: homeData,
    global: {
      nav: navData,
      footer: {},
    },
  };

  return {
    props,
  };
};
