/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useContext } from 'react';

import ThemeContext from '@/context/ThemeContext';
import navData from '@/data/nav';

const Core = () => {
  const { theme } = useContext(ThemeContext);

  return (
    <>
      <section
        key="hero"
        className={`tm-hero tm-4x4 tm-grid-fill text-${theme}`}
      >
        <div
          className="cell relative col-span-4 row-span-4 flex h-full items-center border-none bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/assets/images/core/core-hero.png' }}
        >
          <div className="absolute h-full w-full bg-black/60" />
          <div className="relative w-full text-center">
            <h1 className="relative text-[118px] font-normal">Core Brand</h1>
            <h2 className="absolute left-1/2 top-[13.8vh] -translate-x-1/2 text-[110px] font-normal">
              1
            </h2>
            <img
              className="absolute left-1/2 top-[28vh] -translate-x-1/2"
              src="/assets/images/core/arrow-down.svg"
              alt=""
            />
          </div>
        </div>
        <div className="cell bg-darkBlue col-span-4 row-span-4 flex h-full items-center border-none">
          <div
            className="mx-[6px] rounded-full bg-black"
            style={{
              paddingTop: 'calc(50vw - 6px)',
              width: 'calc(50vw - 6px)',
            }}
          />
        </div>
      </section>
      ,
      <section key="ethos" className="tm-intro">
        <div className="tm-4x4 tm-grid">
          <div className="cell sticky top-0 col-span-2 row-span-4 flex h-full items-center justify-center border-none">
            <h1 className="text-[64px]">Ethos</h1>
          </div>
          <div className="cell col-span-6 row-span-3 flex h-full border-none">
            <img
              src="/assets/images/core/core-ethos.png"
              className="w-100 object-cover"
              alt=""
            />
          </div>
          <div className="cell col-span-2 row-span-2 flex h-[27.6vw] border-none bg-blue" />
          <div className="cell col-span-2 row-span-2 flex h-full border-none">
            <p className="p-[60px]">
              Fans seeking unforgettable moments to the artists, teams, and
              event creators who are powering incredible live events, to
              Ticketmaster employees and the industry at large. And within that
              diversity, the commonality is the passion, joy and excitement of
              being at a live event — or being a part of putting on a live
              event.
            </p>
          </div>
          <div className="cell col-span-2 row-span-2 flex h-full border-none">
            <p className="p-[60px]">
              Those amazing, unforgettable, magical moments that are never the
              same from one night to the next — and it’s Ticketmaster’s mission
              to make that connection between fans and the artists, teams and
              performers they love. The power of our brand lies in that
              connection point.
            </p>
          </div>
        </div>
      </section>
      ,
      <section key="principles" className="tm-sidetrack">
        <div className="tm-sidetrack__primary tm-4x3 relatives">
          <div
            className="absolute h-[27.6vw] w-[50%] bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: 'url(/assets/images/core/core-principals.png)',
            }}
          />
          <div className="cell relative col-span-2 row-span-2 flex h-full items-center justify-center border-none">
            <h1 className="text-[64px]">Principals</h1>
          </div>
          <div className="cell relative col-span-2 col-start-5 row-span-2 flex h-full items-center justify-center border-none">
            <div className="ps-[40px]">
              <h5 className="font-supply my-0 text-[12px] text-[#A7A7A7]">
                HOW WE MAKE IT POSSIBLE
              </h5>
              <h4 className="block text-[36px] leading-[37.5px]">
                We are designing the future of live entertainment.
              </h4>
            </div>
          </div>
          <div className="cell row-span-12 col-span-2 col-start-7 row-start-3 border-none">
            <a
              className="flex h-full w-full items-center justify-center hover:border-none"
              href="#"
            >
              <span className="pe-[22px] text-[18px] font-semibold uppercase text-white	">
                Explore
              </span>
              <img
                className=""
                src="/assets/images/core/arrow-right.svg"
                alt=""
              />
            </a>
          </div>
        </div>
        <div className="tm-sidetrack__secondary">
          <div className="tm-4x4 tm-grid">
            <div
              className="cell relative col-span-4 row-span-2 row-start-2 flex h-full items-center border-none bg-cover bg-center bg-no-repeat"
              style={{
                backgroundImage:
                  'url(https://picsum.photos/seed/picsum/965/503)',
              }}
            />
            <div className="cell relative col-span-2 row-span-2 row-start-2 flex h-full items-center justify-center border-none">
              <div>
                <h5 className="font-supply my-0 text-[12px] text-[#A7A7A7]">
                  PRINCIPLE 1
                </h5>
                <h3 className="text-[48px] leading-[47.5px]">Polished</h3>
              </div>
            </div>
            <div className="cell relative col-span-2 row-span-2 row-start-2 flex h-full items-center border-none">
              <p className="pe-[135px] ps-[20px]">
                It’s Ticketmaster’s mission to make that connection between fans
                and the artists, teams and performers they love. The power of
                our brand lies in that connection point.
              </p>
            </div>
          </div>
          <div className="tm-4x3 tm-grid">
            <div
              className="cell relative col-span-4 row-span-2 flex h-full items-center border-none bg-cover bg-center bg-no-repeat"
              style={{
                backgroundImage:
                  'url(https://picsum.photos/seed/picsum/965/503)',
              }}
            />
            <div className="cell relative col-span-2 row-span-2 flex h-full items-center justify-center border-none">
              <div>
                <h5 className="font-supply my-0 text-[12px] text-[#A7A7A7]">
                  PRINCIPLE 2
                </h5>
                <h3 className="text-[48px] leading-[47.5px]">Dynamic</h3>
              </div>
            </div>
            <div className="cell relative col-span-2 row-span-2 flex h-full items-center border-none">
              <p className="pe-[135px] ps-[20px]">
                Brand elements pulsate, expand, and contract in sync with the
                audio, creating an interplay between sound and motion.
              </p>
            </div>
            <div className="cell col-span-2 row-span-1 row-start-3 flex h-full items-center border-none">
              <a
                className="flex h-full w-full items-center justify-center hover:border-none"
                href="#"
              >
                <img
                  className=""
                  src="/assets/images/core/arrow-left.svg"
                  alt=""
                />
                <span className="ps-[22px] text-[18px] font-semibold uppercase text-white	">
                  Back
                </span>
              </a>
            </div>
          </div>
        </div>
      </section>
      ,
      <section key="foundations" className="tm-gallery">
        <div className="tm-4x4">
          <div className="cell col-span-2 row-span-4 h-full border-none">
            <div className="flex h-full w-full items-center justify-center">
              <h2 className="text-[64px]">Foundations</h2>
            </div>
          </div>
          <div className="cell col-span-2 row-span-4 h-full border-none">
            <div className="flex h-[25%] w-full items-end">
              <h4 className="text-[24px]">Motion</h4>
            </div>
            <div className="flex h-[50%] w-full items-center">
              <img src="/assets/images/core/foundations-motion.png" alt="" />
            </div>
            <div className="h-[25%] w-full" />
          </div>
          <div className="cell col-span-2 row-span-4 h-full border-none">
            <div className="flex h-[25%] w-full items-end">
              <h4 className="text-[24px]">Iconography</h4>
            </div>
            <div className="flex h-[50%] w-full items-center">
              <img src="/assets/images/core/foundations-icons.png" alt="" />
            </div>
            <div className="h-[25%] w-full" />
          </div>
          <div className="cell col-span-2 row-span-4 h-full border-none">
            <div className="flex h-[25%] w-full items-end">
              <h4 className="text-[24px]">Typography</h4>
            </div>
            <div className="flex h-[50%] w-full items-center">
              <img src="/assets/images/core/foundations-type.png" alt="" />
            </div>
            <div className="h-[25%] w-full">
              <a
                className="flex h-full w-full items-center justify-center hover:border-none"
                href="#"
              >
                <span className="pe-[22px] text-[18px] font-semibold uppercase text-white	">
                  Next
                </span>
                <img
                  className=""
                  src="/assets/images/core/arrow-right.svg"
                  alt=""
                />
              </a>
            </div>
          </div>
        </div>
      </section>
      ,
      <section key="architecture" className="tm">
        <div className="tm-4x4 tm-grid">
          <div className="cell col-span-2 row-span-4 flex h-full items-center justify-center border-none">
            <h1 className="text-[64px]">Architecture</h1>
          </div>
          <div className="cell col-span-2 col-start-3 row-span-1 row-start-4 flex h-full items-center justify-center border-none">
            <a
              className="flex h-full w-full items-center justify-center hover:border-none"
              href="#"
            >
              <span className="pe-[22px] text-[18px] font-semibold uppercase text-white	">
                Next
              </span>
              <img
                className=""
                src="/assets/images/core/arrow-right.svg"
                alt=""
              />
            </a>
          </div>
          <div className="cell col-span-2 col-start-5 row-span-1 row-start-1 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-5 row-span-1 row-start-2 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-partners-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-5 row-span-1 row-start-3 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-marketplace-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-5 row-span-1 row-start-4 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-sport-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-7 row-span-1 row-start-1 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-verified-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-7 row-span-1 row-start-2 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-1-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-7 row-span-1 row-start-3 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/tm-t-logo.svg" alt="" />
          </div>
          <div className="cell col-span-2 col-start-7 row-span-1 row-start-4 flex h-full items-center justify-center border-none bg-blue">
            <img src="/assets/images/core/live-nation-logo.svg" alt="" />
          </div>
        </div>
      </section>
      ,
      <section key="resources" className="tm-links">
        <div className="tm-4x4 tm-grid">
          <div className="cell col-span-2 row-span-4 flex h-full items-center justify-center border-none bg-white">
            <h1 className="text-[64px] text-black">Resources</h1>
          </div>
          <div
            className="cell col-span-6 col-start-3 row-span-3 row-start-1 flex h-full items-center justify-center border-none bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: 'url(/assets/images/core/resources.png)',
            }}
          />
          <div className="cell col-span-2 col-start-3 row-span-1 row-start-3 flex h-full items-center justify-center border-none">
            <div className="px-[64px] pb-[78px]">
              <h5 className="font-supply uppenvm usercase my-0 text-[12px] text-[#A7A7A7]">
                Tools for building
              </h5>
              <h3 className="text-[48px] leading-[47.5px]">
                We are designing the future of live entertainment.
              </h3>
            </div>
          </div>
          <div className="cell col-span-6 col-start-3 row-start-4 flex h-full border-none">
            <ul className="tm-links__list !my-0 w-full">
              <li className="tm-links__list-item flex w-full items-center justify-between border-b-[1px] border-white/[.55] bg-black px-[50px] py-[30px] uppercase">
                <p className="!my-0 flex-[1_1_66%]">
                  Taylor Swift & The Eras Tour On Sale.
                </p>
                <p className="!my-0 flex-[1_1_16.5%]">13 FEB 2023</p>
                <a className="text-white" href="#">
                  <span>Download</span>
                  <i />
                </a>
              </li>
              <li className="tm-links__list-item flex w-full items-center justify-between border-b-[1px] border-white/[.55] bg-black px-[50px] py-[30px] uppercase">
                <p className="!my-0 flex-[1_1_66%]">
                  Taylor Swift & The Eras Tour On Sale.
                </p>
                <p className="!my-0 flex-[1_1_16.5%]">13 FEB 2023</p>
                <a className="text-white" href="#">
                  <span>Download</span>
                  <i />
                </a>
              </li>
              <li className="tm-links__list-item flex w-full items-center justify-between border-b-[1px] border-white/[.55] bg-black px-[50px] py-[30px] uppercase">
                <p className="!my-0 flex-[1_1_66%]">
                  Taylor Swift & The Eras Tour On Sale.
                </p>
                <p className="!my-0 flex-[1_1_16.5%]">13 FEB 2023</p>
                <a className="text-white" href="#">
                  <span>Download</span>
                  <i />
                </a>
              </li>
              <li className="tm-links__list-item flex w-full items-center justify-between border-b-[1px] border-white/[.55] bg-black px-[50px] py-[30px] uppercase">
                <p className="!my-0 flex-[1_1_66%]">
                  Taylor Swift & The Eras Tour On Sale.
                </p>
                <p className="!my-0 flex-[1_1_16.5%]">13 FEB 2023</p>
                <a className="text-white" href="#">
                  <span>Download</span>
                  <i />
                </a>
              </li>
              <li className="tm-links__list-item flex w-full items-center justify-between border-b-[1px] border-white/[.55] bg-black px-[50px] py-[30px] uppercase">
                <p className="!my-0 flex-[1_1_66%]">
                  Taylor Swift & The Eras Tour On Sale.
                </p>
                <p className="!my-0 flex-[1_1_16.5%]">13 FEB 2023</p>
                <a className="text-white" href="#">
                  <span>Download</span>
                  <i />
                </a>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export const getStaticProps = async () => {
  const props = {
    global: {
      nav: navData,
      footer: {},
    },
  };

  return {
    props,
  };
};

export default Core;
