import navData from '@/data/nav';
import pages from '@/data/pages';
import OverviewTemplate from '@/templates/overview';

export default OverviewTemplate;

interface IPath {
  params: {
    parent: String;
  };
}

export const getStaticPaths = async () => {
  const paths: IPath[] = pages.map((page) => ({
    params: {
      parent: page.slug,
    },
  }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps = async (context: {
  params: { parent: string };
}) => {
  const { parent } = context.params || {};

  /**
   * This is where data fetching would normally happen.
   * Instead, we will be using static data locally hosted.
   */
  const pageData = pages.find((page) => page.slug === parent);

  const props = {
    page: pageData || {},
    global: {
      nav: navData || {},
      footer: {},
    },
  };

  return {
    props,
  };
};
