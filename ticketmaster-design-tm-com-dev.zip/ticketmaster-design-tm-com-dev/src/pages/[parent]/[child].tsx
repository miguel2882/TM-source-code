import navData from '@/data/nav';
import { childPages } from '@/data/pages';
import ChildTemplate from '@/templates/child';

export default ChildTemplate;

export const getStaticPaths = async () => {
  const paths = childPages.map((page) => ({
    params: {
      parent: page.parent,
      child: page.slug,
    },
  }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps = async (context: {
  params: { parent: string; child: string };
}) => {
  const { parent, child } = context.params || {};

  /**
   * This is where data fetching would normally happen.
   * Instead, we will be using static data locally hosted.
   */
  const pageData = childPages.find(
    (page) => page.slug === child && page.parent === parent,
  );

  const props = {
    page: pageData || {},
    global: {
      nav: navData || {},
      footer: {},
    },
  };

  return {
    props,
  };
};
