import '@/styles/global.css';
import '@/styles/fonts.css';

import gsap from 'gsap';
import ScrollTrigger from 'gsap/dist/ScrollTrigger';
import type { AppProps } from 'next/app';
import { register } from 'swiper/element/bundle';

import Main from '@/layout/Main';
import Meta from '@/layout/Meta';

register();

const MyApp = ({ Component, pageProps }: AppProps) => {
  const { global, page } = pageProps;
  gsap.registerPlugin(ScrollTrigger);
  return (
    <Main nav={global?.nav}>
      <Meta {...page?.meta} />
      <Component {...pageProps} />
    </Main>
  );
};

export default MyApp;
