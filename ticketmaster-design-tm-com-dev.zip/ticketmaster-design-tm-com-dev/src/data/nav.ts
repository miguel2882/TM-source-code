import type { INav } from '@/components/Nav';

const navData: INav = {
  items: [
    {
      label: 'Core',
      link: '/core',
      image: {
        src: '/assets/images/pillar-core-nav.png',
        alt: 'Core',
      },
      children: [
        {
          label: 'Overview',
          link: '/core#overview',
        },
        {
          label: 'Brand Foundations',
          link: '/core#brand-foundations',
        },
        {
          label: 'Logos',
          link: '/core#logos',
        },
        {
          label: 'Brand Guidelines',
          link: '/core/brand-guidelines',
        },
      ],
    },
    {
      label: 'Product',
      link: '/product',
      image: {
        src: '/assets/images/pillar-product-nav.png',
        alt: 'Product',
      },
      children: [
        {
          label: 'Overview',
          link: '/product#overview',
        },
        {
          label: 'Resources & Templates',
          link: '/product#recources-and-templates',
        },
        {
          label: 'Marketplace',
          children: [
            {
              label: 'Overview',
              link: '/product#marketplace-overview',
            },
            {
              label: 'GDS Marketplace',
              link: '/product#gds-marketplace',
            },
          ],
        },
        {
          label: 'Enterprise Overview',
          children: [
            {
              label: 'Test Label',
              link: '/product#enterprise-overview-test-label',
            },
          ],
        },
        {
          label: 'Sport Overview',
          children: [
            {
              label: 'Test Label',
              link: '/product#sport-overview-test-label',
            },
          ],
        },
      ],
    },
    {
      label: 'Marketing',
      link: '/marketing',
      image: {
        src: '/assets/images/pillar-marketing-nav.png',
        alt: 'Marketing',
      },
      children: [
        {
          label: 'Overview',
          link: '/marketing#overview',
        },
        {
          label: 'Resources & Templates',
          link: '/marketing#recources-and-templates',
        },
        {
          label: 'Marketplace',
          children: [
            {
              label: 'Overview',
              link: '/marketing#marketplace-overview',
            },
            {
              label: 'GDS Marketplace',
              link: '/marketing#gds-marketplace',
            },
          ],
        },
        {
          label: 'Enterprise Overview',
          children: [
            {
              label: 'Test Label',
              link: '/marketing#enterprise-overview-test-label',
            },
          ],
        },
        {
          label: 'Sport Overview',
          children: [
            {
              label: 'Test Label',
              link: '/marketing#sport-overview-test-label',
            },
          ],
        },
      ],
    },
    {
      label: 'Career',
      link: '/career',
      image: {
        src: '/assets/images/pillar-careers-nav.png',
        alt: 'Career',
      },
      children: [
        {
          label: 'Working at Ticketmaster',
          link: '/career#working-at-ticketmaster',
        },
        {
          label: 'Design Careers',
          link: '/career#design-careers',
        },
        {
          label: 'Marketing Careers',
          link: '/career#marketing-careeers',
        },
      ],
    },
  ],
};

export default navData;
