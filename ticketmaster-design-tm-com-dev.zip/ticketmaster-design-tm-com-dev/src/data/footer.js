const footerData = {
  title: 'To design the future   of live entertainment.',
  linkLists: [
    {
      title: 'Company',
      links: [
        {
          title: 'Core Brand',
          url: '/core',
        },
        {
          title: 'Product',
          url: '/product',
        },
        {
          title: 'Marketing',
          url: '/marketing',
        },
        {
          title: 'Career',
          url: '/career',
        },
      ],
    },
    {
      title: 'Resources',
      links: [
        {
          title: 'GDS Marketplace',
          url: '/blog',
        },
        {
          title: 'GDS XT',
          url: '/help',
        },
        {
          title: 'Contact Us',
          url: '/contact',
        },
      ],
    },
  ],
};

export default footerData;
