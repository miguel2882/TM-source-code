import type { ISectionLinks } from '@/components/SectionLinks/SectionLinks';

const sectionLinks: ISectionLinks = {
  title: 'Resources',
  id: 'resources',
  theme: 'black',
  type: 'links',
  titleTheme: 'white',
  image: {
    src: '/assets/images/core/resources.png',
    alt: 'Section links image',
    height: 915,
    width: 1446,
  },
  eyebrow: 'Tools for building',
  headline: 'We are designing the future of live entertainment.',
  links: [
    {
      title: 'Taylor Swift & The Eras Tour On Sale.',
      url: 'https://www.ticketmaster.com/taylorswift',
      target: '_blank',
      subtitle: '13 FEB 2023',
    },
    {
      title: 'Red Hot Chili Peppers Tour On Sale.',
      url: 'https://www.ticketmaster.com/redhotchilipeppers',
      target: '_blank',
      subtitle: '27 SEP 2023',
    },
    {
      title: 'Los Angeles Football Club vs. Tigres UANL Tickets',
      url: 'https://www.ticketmaster.com/los-angeles-football-club-vs-tigres-uanl-los-angeles-california-12-07-2021/event/0A005B0B9E3A2F1F',
      target: '_blank',
      subtitle: '27 Sep 2023',
    },
    {
      title: 'Example Title',
      url: 'https://ticketmaster.com/example',
      target: '_blank',
      subtitle: 'Example subtitle',
    },
  ],
};

export default sectionLinks;
