// import type { IHeroProps } from '@/components/Hero';
import type { ISectionIntro } from '@/components/SectionIntro';
import type { IMetaProps } from '@/layout/Meta';
import type { ISectionExtended } from '@/templates/overview';

const meta: IMetaProps = {
  title: 'Product',
  description: 'product',
  canonical: 'https://brand.ticketmaster.com/product',
};

const intro: ISectionIntro = {
  title: 'What we Do',
  id: 'product-intro',
  eyebrow: 'Why we do this',
  headline: 'Give fans simple and fair access to unforgettable live events.',
  theme: 'black',
  image: {
    src: '/assets/images/stock-concert.jpg',
    caption: 'Wilderness Festival 2022',
    alt: 'Amazing concert experience photo',
  },
  support: [
    {
      eyebrow: '01',
      copy: 'Fans seeking unforgettable moments to the artists, teams, and event creators who are powering incredible live events, to Ticketmaster employees and the industry at large. And within that diversity, the commonality is the passion, joy and excitement of being at a live event — or being a part of putting on a live event.',
    },
    {
      eyebrow: '02',
      copy: 'Those amazing, unforgettable, magical moments that are never the same from one night to the next — and it’s Ticketmaster’s mission to make that connection between fans and the artists, teams and performers they love. The power of our brand lies in that connection point.',
    },
  ],
};

const sections: ISectionExtended[] = [
  {
    title: 'Product Principles',
    id: 'product-principles',
    theme: 'black',
    type: 'sidetrack',
  },
];

const data = {
  slug: 'product',
  template: 'parent',
  meta,
  hero: {
    title: 'Product',
    image: {
      src: '/images/product/hero.jpg',
      alt: 'Example alt text',
    },
  },
  intro,
  sections,
};

export default data;
