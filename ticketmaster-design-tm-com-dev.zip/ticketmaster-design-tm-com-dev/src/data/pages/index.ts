import carreerData from './careers';
import coreData from './core';
// subpages
import coreGuidelinesData from './core/guidelines';
import marketingData from './marketing';
import produtData from './product';

const pages = [coreData, carreerData, produtData, marketingData];

export const childPages = [coreGuidelinesData];

export default pages;
