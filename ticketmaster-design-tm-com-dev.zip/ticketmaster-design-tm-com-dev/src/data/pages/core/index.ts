// import type { IHeroProps } from '@/components/Hero';
import type { ISectionIntro } from '@/components/SectionIntro';
import navData from '@/data/nav';
import type { IMetaProps } from '@/layout/Meta';
import type { ISectionExtended } from '@/templates/overview';

import sectionLinks from './sectionLinks';

const meta: IMetaProps = {
  title: 'Core',
  description: 'Core',
  canonical: 'https://brand.ticketmaster.com/core',
};

const intro: ISectionIntro = {
  title: 'Ethos',
  id: 'core-intro',
  eyebrow: 'Why we do this',
  headline: 'We are designing the future of live entertainment.',
  theme: 'black',
  image: {
    src: '/assets/images/core/intro.png',
    caption: 'Wilderness Festival 2022',
    alt: 'Amazing concert experience photo',
  },
  support: [
    {
      eyebrow: '01',
      copy: 'Fans seeking unforgettable moments to the artists, teams, and event creators who are powering incredible live events, to Ticketmaster employees and the industry at large. And within that diversity, the commonality is the passion, joy and excitement of being at a live event — or being a part of putting on a live event.',
    },
    {
      eyebrow: '02',
      copy: 'Fans seeking unforgettable moments to the artists, teams, and event creators who are powering incredible live events, to Ticketmaster employees and the industry at large. And within that diversity, the commonality is the passion, joy and excitement of being at a live event — or being a part of putting on a live event.',
    },
  ],
};

const sections: ISectionExtended[] = [
  {
    title: 'Principles',
    id: 'brand-principles',
    theme: 'black',
    type: 'sidetrack',
  },
  {
    title: 'Foundations',
    id: 'foundations',
    theme: 'black',
    type: 'gallery',
  },
  sectionLinks,
];

const data = {
  slug: 'core',
  template: 'parent',
  meta,
  hero: {
    title: 'Core Brand',
    index: '1',
    image: {
      src: '/assets/images/core/hero.png',
    },
  },
  intro,
  sections,
  global: {
    nav: navData,
  },
};

export default data;
