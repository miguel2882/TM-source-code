import type { IMetaProps } from '@/layout/Meta';

const meta: IMetaProps = {
  title: 'Core Guidelines',
  description: 'Core Guidelines',
  canonical: 'https://brand.ticketmaster.com/core/guidelines',
};

const data = {
  slug: 'guidelines',
  parent: 'core',
  template: 'child',
  meta,
  hero: {
    title: 'Brand Guidelines',
    eyebrow: 'Core Brand Introduction',
    headline:
      'This living brand book provides comprehensive concepts and assets that make up our brand: brand strategy, brand voice and visual identity.',
  },
};

export default data;
