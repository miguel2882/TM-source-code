import type { ISectionLinks } from '@/components/SectionLinks/SectionLinks';

const sectionLinks: ISectionLinks = {
  title: 'Resources',
  id: 'resources',
  theme: 'black',
  type: 'links',
  innerTheme: 'black',
  image: {
    src: '/assets/images/core/resources.png',
    alt: 'Section links image',
    height: 915,
    width: 1446,
  },
  eyebrow: 'Tools for building',
  headline: 'We are designing the future of live entertainment.',
  links: [
    {
      title: 'Taylor Swift & The Eras Tour On Sale.',
      url: 'https://www.ticketmaster.com/taylorswift',
      target: '_blank',
      subtitle: '13 FEB 2023',
    },
    {
      title: 'Ed Sheeran Divide Tour Tickets Available!',
      url: 'https://www.ticketmaster.com/edsheeran',
      target: '_blank',
      subtitle: '20 FEB 2023',
    },
    {
      title: 'Adele 30 Tour - Get Your Tickets!',
      url: 'https://www.ticketmaster.com/adele',
      target: '_blank',
      subtitle: '25 FEB 2023',
    },
    {
      title: 'Coldplay Music of the Spheres Tour Dates Announced.',
      url: 'https://www.ticketmaster.com/coldplay',
      target: '_blank',
      subtitle: '03 MAR 2023',
    },
    {
      title: 'Beyoncé B7 World Tour - Tickets Available Now.',
      url: 'https://www.ticketmaster.com/beyonce',
      target: '_blank',
      subtitle: '10 MAR 2023',
    },
    {
      title: 'Billie Eilish Happier Than Ever Tour - Grab Tickets.',
      url: 'https://www.ticketmaster.com/billieeilish',
      target: '_blank',
      subtitle: '17 MAR 2023',
    },
    {
      title: 'Imagine Dragons Mercury Tour - Get Tickets Now.',
      url: 'https://www.ticketmaster.com/imaginedragons',
      target: '_blank',
      subtitle: '23 MAR 2023',
    },
    {
      title: 'Bruno Mars & Anderson .Paak as Silk Sonic - Live!',
      url: 'https://www.ticketmaster.com/silksonic',
      target: '_blank',
      subtitle: '01 APR 2023',
    },
    {
      title: 'Dua Lipa Future Nostalgia Tour - Tickets on Sale!',
      url: 'https://www.ticketmaster.com/dualipa',
      target: '_blank',
      subtitle: '10 APR 2023',
    },
    {
      title: 'Post Malone Runaway Tour - Get Your Tickets!',
      url: 'https://www.ticketmaster.com/postmalone',
      target: '_blank',
      subtitle: '18 APR 2023',
    },
  ],
};

export default sectionLinks;
