const data = {
  meta: {
    title: 'Home',
    description: 'Home page description',
    canonical: 'https://example.com',
    image: 'https://example.com/image.png',
  },
  intro: {
    1: {
      title:
        'We are relentless in our pursuit to develop the innovations that will unlock unforgettable experiences for fans.',
      subtitle: 'mark yovich',
    },
    2: {
      title: 'Guided by the beats and the harmonies of the world.',
    },
    3: {
      title: 'We design the future of live entertainment.',
    },
  },
  pillars: {
    1: {
      title: 'Core ',
      subtitle:
        'Our brand is more than just a logo or a name - its a representation of our values, our mission, and our commitment to our customers.',
      label: 'Discover',
      link: '/core',
      image: '/images/pillar-core.jpg',
    },
    2: {
      title: 'Product',
      subtitle:
        "We're passionate about creating products that not only meet but exceed the expectations of our customers.",
      label: 'Find Out',
      link: '/product',
      image: '/images/pillar-product.jpg',
    },
  },
};

export default data;
