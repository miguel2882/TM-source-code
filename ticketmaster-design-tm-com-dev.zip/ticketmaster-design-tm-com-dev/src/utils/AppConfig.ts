// FIXME: Update this configuration file based on your project information

export const AppConfig = {
  site_name: 'Ticketmaster',
  title: 'Ticketmaster',
  description: 'Starter code for your Nextjs Boilerplate with Tailwind CSS',
  locale: 'en',
};
