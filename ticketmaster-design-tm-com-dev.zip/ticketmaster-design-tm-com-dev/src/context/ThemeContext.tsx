'use client';

import { createContext } from 'react';

export enum ThemeColors {
  Black = 'black',
  White = 'white',
  Azure = 'azure',
}

interface IThemeContext {
  theme: ThemeColors;
  setTheme: (val: string) => void;
}

const defaultThemeState = {
  theme: ThemeColors.Black,
  setTheme: () => {},
};

const ThemeContext = createContext<IThemeContext>(defaultThemeState);

export default ThemeContext;
