'use client';

import { createContext } from 'react';

interface INavigationContext {
  isNavOpen: boolean;
  setIsNavOpen: (val: boolean) => void;
}

const defaultNavState = {
  isNavOpen: false,
  setIsNavOpen: () => {},
};

const NavigationContext = createContext<INavigationContext>(defaultNavState);

export default NavigationContext;
